import { useQueueStore } from '@/hooks/useQueueStore';
import { AddPatientForm } from '@/components/AddPatientForm';
import { CallNextButton } from '@/components/CallNextButton';
import { PatientCard } from '@/components/PatientCard';
import { StatCard } from '@/components/StatCard';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertCircle, Clock, Users, Activity } from 'lucide-react';
import { Card } from '@/components/ui/card';

/**
 * Home Page - Sistema de Gestão de Fila Médica
 * 
 * Design: Healthcare Elegante
 * - Layout assimétrico com sidebar esquerda (controles) e painel direito (visualização)
 * - Cores médicas: azul profundo (confiança), verde menta (sucesso), âmbar (urgência)
 * - Tipografia: Geist Bold para títulos, Inter para corpo
 * - Animações suaves, feedback visual imediato
 */
export default function Home() {
  const queue = useQueueStore();

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-border bg-card/50 backdrop-blur-sm">
        <div className="container py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Activity className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-card-foreground" style={{ fontFamily: 'Geist, sans-serif' }}>
                🏥 Gestão de Fila Médica
              </h1>
              <p className="text-xs text-muted-foreground">Sistema de priorização de atendimento</p>
            </div>
          </div>
          <div className="text-sm text-muted-foreground">
            {new Date().toLocaleTimeString('pt-BR')}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Sidebar - Controles */}
          <div className="lg:col-span-1 space-y-6">
            {/* Adicionar Paciente */}
            <AddPatientForm onAddPatient={queue.adicionarPaciente} />

            {/* Chamar Próximo */}
            <div className="space-y-3">
              <h3 className="text-sm font-semibold text-card-foreground px-1">Painel de Controle</h3>
              <CallNextButton
                onCallNext={queue.chamarProximo}
                totalAguardando={queue.getTotalAguardando()}
              />
            </div>

            {/* Info de Negócio */}
            <Card className="p-4 bg-accent/5 border-accent/10">
              <div className="space-y-2">
                <h4 className="text-sm font-semibold text-card-foreground flex items-center gap-2">
                  <AlertCircle className="h-4 w-4 text-accent" />
                  Regra de Negócio
                </h4>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  A fila prioritária tem precedência total. O sistema sempre chamará todos os prioritários antes de passar para a fila normal.
                </p>
              </div>
            </Card>
          </div>

          {/* Main Panel - Visualização */}
          <div className="lg:col-span-2 space-y-6">
            {/* Estatísticas */}
            <div className="grid grid-cols-3 gap-4">
              <StatCard
                label="Total Prioritário"
                value={queue.getTotalPrioritario()}
                icon={AlertCircle}
                variant="primary"
              />
              <StatCard
                label="Total Normal"
                value={queue.getTotalNormal()}
                icon={Users}
                variant="secondary"
              />
              <StatCard
                label="Aguardando"
                value={queue.getTotalAguardando()}
                icon={Clock}
                variant="accent"
              />
            </div>

            {/* Tabs */}
            <Tabs defaultValue="filas" className="w-full">
              <TabsList className="grid w-full grid-cols-3 bg-muted/50">
                <TabsTrigger value="filas">📋 Filas Atuais</TabsTrigger>
                <TabsTrigger value="historico">✅ Histórico</TabsTrigger>
                <TabsTrigger value="stats">📊 Estatísticas</TabsTrigger>
              </TabsList>

              {/* Filas Atuais */}
              <TabsContent value="filas" className="space-y-6 mt-6">
                {/* Fila Prioritária */}
                <div className="space-y-3">
                  <h3 className="text-lg font-semibold text-card-foreground flex items-center gap-2">
                    <AlertCircle className="h-5 w-5 text-destructive" />
                    Fila Prioritária
                  </h3>
                  {queue.prioritaria.length > 0 ? (
                    <div className="space-y-2">
                      {queue.prioritaria.map((paciente) => (
                        <PatientCard key={paciente.id} patient={paciente} />
                      ))}
                    </div>
                  ) : (
                    <Card className="p-8 text-center bg-muted/30 border-dashed">
                      <p className="text-muted-foreground">Fila vazia</p>
                    </Card>
                  )}
                </div>

                {/* Fila Normal */}
                <div className="space-y-3">
                  <h3 className="text-lg font-semibold text-card-foreground flex items-center gap-2">
                    <Users className="h-5 w-5 text-primary" />
                    Fila Normal
                  </h3>
                  {queue.normal.length > 0 ? (
                    <div className="space-y-2">
                      {queue.normal.map((paciente) => (
                        <PatientCard key={paciente.id} patient={paciente} />
                      ))}
                    </div>
                  ) : (
                    <Card className="p-8 text-center bg-muted/30 border-dashed">
                      <p className="text-muted-foreground">Fila vazia</p>
                    </Card>
                  )}
                </div>
              </TabsContent>

              {/* Histórico */}
              <TabsContent value="historico" className="space-y-4 mt-6">
                <h3 className="text-lg font-semibold text-card-foreground">Últimos Atendimentos</h3>
                {queue.historico.length > 0 ? (
                  <div className="space-y-2">
                    {queue.historico.map((paciente) => (
                      <PatientCard key={paciente.id} patient={paciente} showAtendimento={true} />
                    ))}
                  </div>
                ) : (
                  <Card className="p-8 text-center bg-muted/30 border-dashed">
                    <p className="text-muted-foreground">Nenhum atendimento realizado ainda</p>
                  </Card>
                )}
              </TabsContent>

              {/* Estatísticas Detalhadas */}
              <TabsContent value="stats" className="space-y-6 mt-6">
                <h3 className="text-lg font-semibold text-card-foreground">Resumo do Dia</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <StatCard
                    label="Total Prioritário"
                    value={queue.getTotalPrioritario()}
                    icon={AlertCircle}
                    variant="primary"
                  />
                  <StatCard
                    label="Total Normal"
                    value={queue.getTotalNormal()}
                    icon={Users}
                    variant="secondary"
                  />
                  <StatCard
                    label="Atendidos"
                    value={queue.historico.length}
                    icon={Activity}
                    variant="accent"
                  />
                </div>

                {/* Detalhes */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card className="p-6 border-0 bg-card/50">
                    <h4 className="font-semibold text-card-foreground mb-4">Taxa de Atendimento</h4>
                    <div className="space-y-3">
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm text-muted-foreground">Prioritários</span>
                          <span className="text-sm font-semibold text-card-foreground">
                            {queue.historico.filter((p) => p.tipo === 'Prioritária').length}
                          </span>
                        </div>
                        <div className="h-2 bg-muted rounded-full overflow-hidden">
                          <div
                            className="h-full bg-destructive"
                            style={{
                              width: `${
                                queue.getTotalPrioritario() > 0
                                  ? (queue.historico.filter((p) => p.tipo === 'Prioritária').length /
                                      queue.getTotalPrioritario()) *
                                    100
                                  : 0
                              }%`,
                            }}
                          />
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm text-muted-foreground">Normais</span>
                          <span className="text-sm font-semibold text-card-foreground">
                            {queue.historico.filter((p) => p.tipo === 'Normal').length}
                          </span>
                        </div>
                        <div className="h-2 bg-muted rounded-full overflow-hidden">
                          <div
                            className="h-full bg-primary"
                            style={{
                              width: `${
                                queue.getTotalNormal() > 0
                                  ? (queue.historico.filter((p) => p.tipo === 'Normal').length /
                                      queue.getTotalNormal()) *
                                    100
                                  : 0
                              }%`,
                            }}
                          />
                        </div>
                      </div>
                    </div>
                  </Card>

                  <Card className="p-6 border-0 bg-card/50">
                    <h4 className="font-semibold text-card-foreground mb-4">Status Atual</h4>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center p-3 bg-background/50 rounded-lg">
                        <span className="text-sm text-muted-foreground">Fila Prioritária</span>
                        <span className="text-lg font-bold text-destructive">{queue.prioritaria.length}</span>
                      </div>
                      <div className="flex justify-between items-center p-3 bg-background/50 rounded-lg">
                        <span className="text-sm text-muted-foreground">Fila Normal</span>
                        <span className="text-lg font-bold text-primary">{queue.normal.length}</span>
                      </div>
                      <div className="flex justify-between items-center p-3 bg-background/50 rounded-lg">
                        <span className="text-sm text-muted-foreground">Total Aguardando</span>
                        <span className="text-lg font-bold text-accent">{queue.getTotalAguardando()}</span>
                      </div>
                    </div>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>
    </div>
  );
}
