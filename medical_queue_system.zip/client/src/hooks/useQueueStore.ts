import { useState, useCallback } from 'react';

export interface Patient {
  id: string;
  nome: string;
  chegada: string;
  tipo: 'Prioritária' | 'Normal';
  atendimento?: string;
}

interface QueueStore {
  prioritaria: Patient[];
  normal: Patient[];
  historico: Patient[];
}

export function useQueueStore() {
  const [store, setStore] = useState<QueueStore>({
    prioritaria: [],
    normal: [],
    historico: [],
  });

  const adicionarPaciente = useCallback((nome: string, tipo: 'Prioritária' | 'Normal') => {
    const paciente: Patient = {
      id: `${Date.now()}-${Math.random()}`,
      nome,
      chegada: new Date().toLocaleTimeString('pt-BR'),
      tipo,
    };

    setStore((prev) => {
      if (tipo === 'Prioritária') {
        return {
          ...prev,
          prioritaria: [...prev.prioritaria, paciente],
        };
      } else {
        return {
          ...prev,
          normal: [...prev.normal, paciente],
        };
      }
    });

    return paciente;
  }, []);

  const chamarProximo = useCallback((): Patient | null => {
    let paciente: Patient | null = null;

    setStore((prev) => {
      if (prev.prioritaria.length > 0) {
        paciente = prev.prioritaria[0];
        return {
          ...prev,
          prioritaria: prev.prioritaria.slice(1),
          historico: [
            {
              ...paciente,
              atendimento: new Date().toLocaleTimeString('pt-BR'),
            },
            ...prev.historico,
          ],
        };
      } else if (prev.normal.length > 0) {
        paciente = prev.normal[0];
        return {
          ...prev,
          normal: prev.normal.slice(1),
          historico: [
            {
              ...paciente,
              atendimento: new Date().toLocaleTimeString('pt-BR'),
            },
            ...prev.historico,
          ],
        };
      }
      return prev;
    });

    return paciente;
  }, []);

  const removerPaciente = useCallback((id: string, tipo: 'Prioritária' | 'Normal') => {
    setStore((prev) => {
      if (tipo === 'Prioritária') {
        return {
          ...prev,
          prioritaria: prev.prioritaria.filter((p) => p.id !== id),
        };
      } else {
        return {
          ...prev,
          normal: prev.normal.filter((p) => p.id !== id),
        };
      }
    });
  }, []);

  const getTotalPrioritario = useCallback(() => {
    return store.prioritaria.length + store.historico.filter((p) => p.tipo === 'Prioritária').length;
  }, [store]);

  const getTotalNormal = useCallback(() => {
    return store.normal.length + store.historico.filter((p) => p.tipo === 'Normal').length;
  }, [store]);

  const getTotalAguardando = useCallback(() => {
    return store.prioritaria.length + store.normal.length;
  }, [store]);

  return {
    ...store,
    adicionarPaciente,
    chamarProximo,
    removerPaciente,
    getTotalPrioritario,
    getTotalNormal,
    getTotalAguardando,
  };
}
