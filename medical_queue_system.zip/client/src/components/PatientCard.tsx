import { Patient } from '@/hooks/useQueueStore';
import { AlertCircle, Clock, User } from 'lucide-react';
import { Card } from './ui/card';

interface PatientCardProps {
  patient: Patient;
  showAtendimento?: boolean;
}

export function PatientCard({ patient, showAtendimento = false }: PatientCardProps) {
  const isPriority = patient.tipo === 'Prioritária';

  return (
    <Card className="relative overflow-hidden border-l-4 p-4 transition-all duration-200 hover:shadow-lg">
      {/* Barra lateral de prioridade */}
      <div
        className={`absolute left-0 top-0 bottom-0 w-1 ${
          isPriority ? 'bg-destructive' : 'bg-primary'
        }`}
      />

      <div className="ml-2 space-y-3">
        {/* Header com nome e tipo */}
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-2 flex-1">
            <User className="h-5 w-5 text-muted-foreground flex-shrink-0" />
            <div className="min-w-0 flex-1">
              <h3 className="font-semibold text-card-foreground truncate">{patient.nome}</h3>
              <div className="flex items-center gap-2 mt-1">
                <span
                  className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    isPriority
                      ? 'bg-destructive/10 text-destructive'
                      : 'bg-primary/10 text-primary'
                  }`}
                >
                  {isPriority && <AlertCircle className="h-3 w-3" />}
                  {patient.tipo}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Timestamps */}
        <div className="space-y-1.5 text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            <Clock className="h-4 w-4 flex-shrink-0" />
            <span>Chegada: {patient.chegada}</span>
          </div>
          {showAtendimento && patient.atendimento && (
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 flex-shrink-0" />
              <span>Atendimento: {patient.atendimento}</span>
            </div>
          )}
        </div>
      </div>
    </Card>
  );
}
