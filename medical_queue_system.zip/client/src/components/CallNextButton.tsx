import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Bell, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogHeader,
  AlertDialogTitle,
} from './ui/alert-dialog';
import { Patient } from '@/hooks/useQueueStore';

interface CallNextButtonProps {
  onCallNext: () => Patient | null;
  totalAguardando: number;
}

export function CallNextButton({ onCallNext, totalAguardando }: CallNextButtonProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [lastCalled, setLastCalled] = useState<Patient | null>(null);
  const [showConfirmation, setShowConfirmation] = useState(false);

  const handleCallNext = () => {
    if (totalAguardando === 0) {
      toast.info('Não há pacientes na fila');
      return;
    }

    const paciente = onCallNext();
    if (paciente) {
      setLastCalled(paciente);
      setIsOpen(true);
      setShowConfirmation(true);

      // Auto-close after 5 seconds
      const timer = setTimeout(() => {
        setIsOpen(false);
      }, 5000);

      return () => clearTimeout(timer);
    }
  };

  return (
    <>
      <Button
        onClick={handleCallNext}
        disabled={totalAguardando === 0}
        className="w-full bg-secondary hover:bg-secondary/90 text-secondary-foreground font-bold h-12 text-base gap-2"
      >
        <Bell className="h-5 w-5" />
        CHAMAR PRÓXIMO PACIENTE
      </Button>

      <AlertDialog open={isOpen} onOpenChange={setIsOpen}>
        <AlertDialogContent className="border-0 shadow-2xl">
          <AlertDialogHeader>
            <div className="flex items-center gap-3">
              <div className="h-12 w-12 rounded-full bg-secondary/10 flex items-center justify-center">
                <Bell className="h-6 w-6 text-secondary" />
              </div>
              <div>
                <AlertDialogTitle className="text-xl">Chamando agora</AlertDialogTitle>
                <AlertDialogDescription className="text-base mt-1">
                  Paciente em atendimento
                </AlertDialogDescription>
              </div>
            </div>
          </AlertDialogHeader>

          {lastCalled && (
            <div className="space-y-4 py-4">
              <div className="bg-secondary/5 rounded-lg p-4 border border-secondary/10">
                <p className="text-sm text-muted-foreground mb-1">Nome</p>
                <p className="text-2xl font-bold text-card-foreground">{lastCalled.nome}</p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="bg-background rounded-lg p-3 border border-border">
                  <p className="text-xs text-muted-foreground mb-1">Tipo</p>
                  <p className="font-semibold text-card-foreground">{lastCalled.tipo}</p>
                </div>
                <div className="bg-background rounded-lg p-3 border border-border">
                  <p className="text-xs text-muted-foreground mb-1">Chegada</p>
                  <p className="font-semibold text-card-foreground">{lastCalled.chegada}</p>
                </div>
              </div>
            </div>
          )}

          <AlertDialogCancel className="bg-muted hover:bg-muted/90 text-muted-foreground border-0">
            Fechar
          </AlertDialogCancel>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
