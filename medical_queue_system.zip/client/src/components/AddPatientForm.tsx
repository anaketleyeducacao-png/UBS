import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import { Card } from './ui/card';
import { UserPlus } from 'lucide-react';
import { toast } from 'sonner';

interface AddPatientFormProps {
  onAddPatient: (nome: string, tipo: 'Prioritária' | 'Normal') => void;
}

export function AddPatientForm({ onAddPatient }: AddPatientFormProps) {
  const [nome, setNome] = useState('');
  const [tipo, setTipo] = useState<'Prioritária' | 'Normal'>('Normal');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!nome.trim()) {
      toast.error('Por favor, insira o nome do paciente');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      onAddPatient(nome, tipo);
      toast.success(`Paciente ${nome} adicionado à fila ${tipo}!`);
      setNome('');
      setTipo('Normal');
      setIsLoading(false);
    }, 300);
  };

  return (
    <Card className="p-6 border-0 bg-card/50 backdrop-blur-sm">
      <div className="mb-6">
        <h2 className="text-lg font-semibold text-card-foreground flex items-center gap-2">
          <UserPlus className="h-5 w-5 text-primary" />
          Registrar Novo Paciente
        </h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="nome" className="text-sm font-medium">
            Nome do Paciente
          </Label>
          <Input
            id="nome"
            placeholder="Ex: João Silva"
            value={nome}
            onChange={(e) => setNome(e.target.value)}
            disabled={isLoading}
            className="bg-background/50"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="tipo" className="text-sm font-medium">
            Tipo de Atendimento
          </Label>
          <Select value={tipo} onValueChange={(value) => setTipo(value as 'Prioritária' | 'Normal')} disabled={isLoading}>
            <SelectTrigger id="tipo" className="bg-background/50">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Normal">Normal</SelectItem>
              <SelectItem value="Prioritária">Prioritária</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Button
          type="submit"
          disabled={isLoading}
          className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold h-10"
        >
          {isLoading ? 'Adicionando...' : 'Adicionar à Fila'}
        </Button>
      </form>
    </Card>
  );
}
