import { Card } from './ui/card';
import { LucideIcon } from 'lucide-react';

interface StatCardProps {
  label: string;
  value: number;
  icon: LucideIcon;
  variant?: 'primary' | 'secondary' | 'accent';
}

export function StatCard({ label, value, icon: Icon, variant = 'primary' }: StatCardProps) {
  const variantStyles = {
    primary: 'bg-primary/5 border-primary/10 text-primary',
    secondary: 'bg-secondary/5 border-secondary/10 text-secondary',
    accent: 'bg-accent/5 border-accent/10 text-accent',
  };

  return (
    <Card className={`p-4 border ${variantStyles[variant]}`}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-muted-foreground font-medium">{label}</p>
          <p className="text-3xl font-bold text-card-foreground mt-2">{value}</p>
        </div>
        <div className={`h-12 w-12 rounded-lg ${variantStyles[variant].split(' ')[0]} flex items-center justify-center`}>
          <Icon className="h-6 w-6" />
        </div>
      </div>
    </Card>
  );
}
