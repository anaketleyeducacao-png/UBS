# Sistema de Gestão de Fila Médica - Design

## Três Abordagens de Design

### 1. **Minimalista Clínico**
Estética limpa e profissional, inspirada em interfaces médicas modernas. Foco em clareza e eficiência.
**Probabilidade:** 0.08

### 2. **Dashboard Dinâmico**
Interface energética com animações fluidas, cores vibrantes e layout assimétrico. Sente-se como um painel de controle real.
**Probabilidade:** 0.05

### 3. **Healthcare Elegante**
Design sofisticado com tipografia premium, espaçamento generoso e elementos gráficos sutis. Transmite confiança e profissionalismo.
**Probabilidade:** 0.07

---

## Abordagem Escolhida: **Healthcare Elegante**

### Design Movement
Inspirado em interfaces de saúde premium (Apple Health, Fitbit, interfaces hospitalares modernas). Combina minimalismo com sofisticação, com ênfase em legibilidade e confiança.

### Core Principles
1. **Clareza Hierárquica**: Informações críticas (pacientes aguardando, próximo a chamar) em destaque visual imediato
2. **Confiança através da Precisão**: Tipografia refinada, espaçamento consistente, cores médicas estabelecidas
3. **Fluidez Intuitiva**: Transições suaves, feedback visual imediato, sem fricção na navegação
4. **Acessibilidade Prioritária**: Alto contraste, fontes legíveis, estados claros para cada ação

### Color Philosophy
- **Primária**: Azul médico profundo (`oklch(0.55 0.15 250)`) - transmite confiança, serenidade
- **Secundária**: Verde menta suave (`oklch(0.75 0.08 160)`) - sucesso, confirmação
- **Destaque**: Âmbar quente (`oklch(0.70 0.12 60)`) - atenção, urgência (para fila prioritária)
- **Neutros**: Cinza claro para backgrounds, cinza escuro para texto

### Layout Paradigm
Layout assimétrico com **sidebar esquerda fixa** (controles) e **painel direito expansível** (visualização de dados). Não usa grid centrado. Prioriza ação sobre visualização.

### Signature Elements
1. **Cards de Pacientes**: Elevados com sombra suave, bordas arredondadas, indicador de prioridade visual (barra colorida lateral)
2. **Badge de Prioridade**: Ícone + texto, cores distintas (vermelho para prioritário, azul para normal)
3. **Animação de Chamada**: Quando paciente é chamado, card se destaca com pulse suave + som opcional

### Interaction Philosophy
- Botões respondem com escala leve (0.97) e feedback tátil visual
- Hover states sutis mas perceptíveis
- Modais para confirmações críticas
- Toast notifications para feedback imediato
- Transições de 150-250ms para ações

### Animation
- **Entrada de Cards**: Fade-in + slide-up de 200ms (ease-out)
- **Hover em Cards**: Elevação suave, sombra aumentada
- **Chamada de Paciente**: Pulse 1.5s, seguido de fade-out quando removido
- **Transição de Abas**: Fade-in de 150ms
- Respeita `prefers-reduced-motion`

### Typography System
- **Display**: Geist Bold (títulos principais) - peso 700
- **Heading**: Geist SemiBold (seções) - peso 600
- **Body**: Inter Regular (texto corpo) - peso 400
- **Small**: Inter Regular (labels, timestamps) - peso 400, tamanho reduzido
- Escala: 12px → 14px → 16px → 18px → 24px → 32px

### Brand Essence
**Uma linha:** Sistema que torna o atendimento médico mais humano e organizado, eliminando confusão e priorizando quem mais precisa.

**3 Adjetivos:** Confiável, Intuitivo, Compassivo

### Brand Voice
- Títulos: Diretos, profissionais, sem jargão desnecessário
- CTAs: Ação clara ("Chamar Próximo", "Adicionar Paciente")
- Microcopy: Tom amigável mas formal ("Paciente adicionado com sucesso")
- Exemplos:
  - ❌ "Bem-vindo ao nosso sistema"
  - ✅ "Gestão de Fila Médica"
  - ❌ "Clique aqui para começar"
  - ✅ "Adicionar Paciente"

### Wordmark & Logo
Logo: Símbolo de estetoscópio + fila em forma de linha, em azul médico. Sem texto, apenas ícone.

### Signature Brand Color
Azul médico: `oklch(0.55 0.15 250)` - cor que aparece em header, botões primários, badges

---

## Estrutura da Interface

### Layout Principal
```
┌─────────────────────────────────────────┐
│ 🏥 Header (Logo + Título)               │
├─────────────────────────────────────────┤
│ Sidebar (Esq)  │  Painel Principal (Dir)│
│ - Adicionar    │  - Abas:              │
│ - Controles    │    * Filas Atuais     │
│ - Info Negócio │    * Histórico        │
│                │    * Estatísticas     │
└─────────────────────────────────────────┘
```

### Componentes Principais
1. **Header**: Logo + Título + Relógio em tempo real
2. **Sidebar**: Formulário de adição + Botão "Chamar Próximo" + Info
3. **Tabs**: Filas, Histórico, Estatísticas
4. **Patient Cards**: Cada paciente em card elevado
5. **Stats Metrics**: Cards de métrica (total prioritário, total normal, aguardando)
6. **Modais**: Confirmação ao chamar paciente

